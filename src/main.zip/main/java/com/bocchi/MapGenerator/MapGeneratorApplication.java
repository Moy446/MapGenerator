package com.bocchi.MapGenerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MapGeneratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(MapGeneratorApplication.class, args);
	}
}
