package com.bocchi.MapGenerator;
import java_cup.runtime.Symbol;


public class ElementoMapa {
    public String tipo;
    public int x,y,z;
    public double altura;

    public ElementoMapa(String tipo, int x, int y, int z, double altura) {
        this.tipo = tipo;
        this.x = x;
        this.y = y;
        this.z = z;
        this.altura = altura;
    }

    public String toString(){
        return tipo + " en (" + x + "," + y + "," + z + ") con altura " + altura;
    }
}
